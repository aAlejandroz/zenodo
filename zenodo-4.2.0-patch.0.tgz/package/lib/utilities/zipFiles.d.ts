/**
 *
 * This function zips an array of File objects into a single zip file.
 * @param files - Array of File objects to be zipped
 * @param zipName - The name of the resulting zip file (without extension)
 * @returns A promise that resolves to a File object representing the zip file.
 */
export declare function zipFiles(files: File[], zipName: string): Promise<File>;
//# sourceMappingURL=zipFiles.d.ts.map