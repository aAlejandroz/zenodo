export * from './Zenodo.ts';
export * from './utilities/zipFiles.ts';
//# sourceMappingURL=index.d.ts.map