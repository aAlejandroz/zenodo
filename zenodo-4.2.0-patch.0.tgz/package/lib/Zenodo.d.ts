import type { Logger } from 'cheminfo-types';
import type { ZenodoAuthenticationStatesType } from './ZenodoAuthenticationStates.ts';
import type { ListDepositionsOptions } from './records/ListDepositionsOptions.ts';
import { Record } from './records/Record.ts';
import type { Identifier, ZenodoMetadata, ZenodoRecordAccess } from './records/RecordType.ts';
import type { ZenodoReview } from './records/RequestType.ts';
interface ZenodoOptions {
    accessToken: string;
    host?: string;
    userAgent?: string;
    logger?: Logger;
}
export interface PublicRecordOptions {
    isPublished?: boolean;
}
export declare class Zenodo {
    host: string;
    accessToken: string;
    baseURL: string;
    userAgent?: string;
    logger?: Logger;
    authenticationState: ZenodoAuthenticationStatesType;
    constructor(options: ZenodoOptions);
    /**
     * Create a new Zenodo instance.
     * This method authenticates the user and initializes a new Zenodo instance.
     * @param options - the options for creating a Zenodo instance
     * @throws {Error} If the authentication fails
     * @returns a new Zenodo instance
     */
    static create(options: ZenodoOptions): Promise<Zenodo>;
    /**
     * Verify the authentication state of the Zenodo instance.
     * This method checks if the access token is valid by making a request to the Zenodo API.
     * @returns true if authentication is successful, false otherwise.
     */
    verifyAuthentication(): Promise<boolean>;
    /**
     * Lists all records in the Zenodo instance.
     * @param options - options for listing records
     * @description Lists all records in the Zenodo instance.
     * @returns An array of Record objects representing the records in the Zenodo instance.
     */
    listRecords(options?: ListDepositionsOptions): Promise<Record[]>;
    /**
     * Creates a new record in the Zenodo instance.
     * @param metadata - the metadata for the new record
     * @param options - additional options for the record
     * @param options.access - access control settings for the new record (files visibility and optional embargo)
     * @throws {Error} If the metadata is invalid or the request fails
     * @returns The created record object
     */
    createRecord(metadata: ZenodoMetadata, options?: {
        access?: ZenodoRecordAccess;
    }): Promise<Record>;
    /**
     * Retrieve a public deposition record
     * @param id - the deposition id
     * @param options - additional options for the request
     * @throws {Error} If the deposition does not exist or the ID is undefined
     * @returns The public deposition record
     */
    retrieveRecord(id: Identifier, options?: PublicRecordOptions): Promise<Record>;
    /**
     * List files in a deposition
     * @param depositionId - the deposition id to retrieve requests for
     * @returns An object containing the total number of requests and the list of requests
     */
    retrieveRequests(depositionId?: Identifier): Promise<{
        hits: {
            total: number;
            hits: ZenodoReview[];
        };
    }>;
    /**
     * Retrieve all versions of a deposition
     * @param id - the deposition id
     * @returns unvalidated array of deposition versions
     */
    retrieveVersions(id: Identifier): Promise<Record[]>;
    deleteRecord(id: Identifier, options?: PublicRecordOptions): Promise<void>;
}
export {};
//# sourceMappingURL=Zenodo.d.ts.map