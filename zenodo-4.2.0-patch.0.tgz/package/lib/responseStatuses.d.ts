interface ResponseStatusInfo {
    code: number;
    name: string;
    description: string;
}
export declare const responseStatuses: Record<number, ResponseStatusInfo>;
export {};
//# sourceMappingURL=responseStatuses.d.ts.map