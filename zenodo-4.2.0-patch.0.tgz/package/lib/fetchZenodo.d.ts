import type { Zenodo } from './Zenodo.ts';
interface FetchZenodoOptions {
    /**
     * The route to append to the Zenodo base URL.
     * @default 'user/records'
     */
    route?: string;
    /**
     * The HTTP method to use for the request.
     * @default 'GET'
     */
    method?: string;
    /**
     * The content type of the request body.
     * @default 'application/json' if body is not a FormData, undefined otherwise
     */
    contentType?: string;
    /**
     * The expected status code of the response. If the response status code does not match this
     * value, we will retry.
     * @default 200
     */
    expectedStatus?: number;
    searchParams?: Record<string, string>;
    body?: string | File;
    /**
     * Maximum number of retry attempts.
     * @default 3
     */
    maxRetries?: number;
    /**
     * Base delay between retries in milliseconds.
     * @default 1000
     */
    baseDelay?: number;
    /**
     * Whether to use exponential backoff for retry delays.
     * @default true
     */
    useExponentialBackoff?: boolean;
    /**
     * Whether to respect rate limit headers and wait accordingly.
     * @default true
     */
    respectRateLimit?: boolean;
}
/**
 * Fetch data from the Zenodo API with retry logic.
 * @param zenodo - The Zenodo instance containing the base URL and access token.
 * @param options - The options for the fetch request.
 * @returns The response from the Zenodo API.
 */
export declare function fetchZenodo(zenodo: Zenodo, options: FetchZenodoOptions): Promise<Response>;
export {};
//# sourceMappingURL=fetchZenodo.d.ts.map