import type { Zenodo } from './Zenodo.ts';
interface ZenodoFileType {
    created: string;
    updated: string;
    mimetype: string;
    version_id: string;
    file_id: string;
    bucket_id: string;
    metadata: object;
    access: {
        hidden: boolean;
    };
    links: {
        self: string;
        content: string;
        commit: string;
    };
    key: string;
    transfer: {
        type: string;
    };
    status: string;
    checksum: string;
    size: number;
    storage_class: string;
}
export declare class ZenodoFile {
    private zenodo;
    value: ZenodoFileType;
    constructor(zenodo: Zenodo, file: unknown);
    getContentResponse(): Promise<Response>;
}
export {};
//# sourceMappingURL=ZenodoFile.d.ts.map