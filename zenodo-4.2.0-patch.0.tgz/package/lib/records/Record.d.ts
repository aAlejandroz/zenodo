import type { Zenodo } from '../Zenodo.ts';
import { ZenodoFile } from '../ZenodoFile.ts';
import type { ZenodoMetadata, ZenodoRecord, ZenodoRecordAccess } from './RecordType.ts';
import type { ZenodoReview } from './RequestType.ts';
interface newVersionOptions {
    linkFiles?: boolean;
    getDOI?: boolean;
}
export declare class Record {
    value: ZenodoRecord;
    private zenodo;
    constructor(zenodo: Zenodo, value: unknown);
    uploadFiles(files: File[]): Promise<ZenodoFile[]>;
    uploadFilesAsZip(files: File[], zipFileName: string): Promise<ZenodoFile[]>;
    listFiles(): Promise<ZenodoFile[]>;
    deleteFile(filename: string): Promise<void>;
    deleteFiles(filenames: string[]): Promise<void>;
    deleteAllFiles(): Promise<void>;
    retrieveFile(filename: string): Promise<ZenodoFile>;
    update(metadata: ZenodoMetadata, options?: {
        access?: ZenodoRecordAccess;
    }): Promise<Record>;
    publish(): Promise<Record>;
    newVersion(options?: newVersionOptions): Promise<Record>;
    submitForReview(url?: string): Promise<ZenodoReview>;
    /**
     * Adds the deposition to a community.
     * This method adds the deposition to a community by creating a review request.
     * @param communityId - the ID of the community to add the deposition to
     * @returns the response from the Zenodo API
     */
    addToCommunity(communityId: string): Promise<unknown>;
    reserveDOI(): Promise<Record>;
}
export {};
//# sourceMappingURL=Record.d.ts.map